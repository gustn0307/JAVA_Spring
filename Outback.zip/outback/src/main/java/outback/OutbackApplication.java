package outback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OutbackApplication {

	public static void main(String[] args) {
		SpringApplication.run(OutbackApplication.class, args);
	}

}
