package outback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OutbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
