package ncs12.service;

import org.springframework.ui.Model;

public interface BoardService {

	String getList(Model model);

}
