package ncs12.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/mem/*")
public class MemberController {

	@GetMapping("reg")
	public String regPage() {
		return "member/registration"; // templates 경로
	}
	
	@GetMapping("login")
	public String loginPage() {
		return "member/login"; // templates 경로
	}
}
