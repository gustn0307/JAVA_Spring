/**
 * 
 */
 

$(function(){
	weatherStart();
});
var weatherTimmer;
function weatherStart(){
	getWeather();
	weatherTimmer=setTimeout(weatherStart, 60000);
} 
function getWeather(){
	var apiURI="https://api.openweathermap.org/data/2.5/weather?q=seoul&appid=6d5759fbb75574c53062ce266b894e1f";
	
	$.ajax({
		url: apiURI,
		dataType:"json",
		success:function(result){
			//console.log("lon:"+ result.coord.lon);
			//console.log("lat:"+ result.coord.lat);
			var temp=parseInt(parseFloat(result.main.temp)-273.15);
			console.log("현재온도:" + parseInt(parseFloat(result.main.temp)-273.15));
			console.log(result);
			var imgURL = "http://openweathermap.org/img/w/" + result.weather[0].icon + ".png";
			$("#w_icon").css("background-image", 'url('+imgURL+')');
			$("#temp").text(temp);
		}
	});
}