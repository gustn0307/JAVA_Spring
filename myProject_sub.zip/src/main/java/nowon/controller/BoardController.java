package nowon.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import nowon.domain.dto.board.BoardSaveDto;
import nowon.domain.dto.board.BoardUpdateDto;
import nowon.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService service;
	
	// 게시글 페이지 이동 + 게시글 정보
	@GetMapping("/boards")
	public String list(Model model) { // Model : 페이지에 데이터를 전달해주는 역할
		service.list(model);
		return "/board/list"; // templates 페이지 경로 .htmp 생략
	}
	// 글쓰기 페이지 이동 (회원 또는 관리자 인증이 완료된 경우)
	@GetMapping("/boards-write")
	public String page() {
		return "/board/write";
	}
	
	// 게시글 저장
	@PostMapping("/boards/write")
	public String save(BoardSaveDto dto) {
		service.save(dto);
		return "redirect:/boards"; //list 페이지를 호출하여서 페이지 이동
	}
	
	// 상세 페이지 이동 + 상세 정보 보기
	@GetMapping("/boards/{bno}")
	public String detail(@PathVariable long bno, Model model) {
		service.detail(bno, model);
		return "board/detail";
	}
	
	// 수정 작업
	@PutMapping("/boards/{bno}")
	public String update(@PathVariable long bno, BoardUpdateDto dto) {
		service.update(bno, dto);
		return "redirect:/boards/"+bno;
	}
	
	// 게시글 삭제
	@DeleteMapping("/boards/{bno}")
	public String delete(@PathVariable long bno) {
		service.delete(bno);
		return "redirect:/boards";
	}
}
