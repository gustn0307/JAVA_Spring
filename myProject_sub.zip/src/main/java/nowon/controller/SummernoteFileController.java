package nowon.controller;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.HashMap;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class SummernoteFileController { // 글쓰기에서 summernote에 파일 업로드하는 역할
	
	// ajax로 요청
	//@ResponseBody // body에 json 형태로 리턴
	@PostMapping("/uploadSummernoteImageFile")
	public HashMap<String, String> uploadSummernoteImageFile(MultipartFile file) throws IOException {
		//System.out.println(file.getOriginalFilename());
		
		// 업로드된 파일 이름변경: 확장자와 이름 분리하고 나중에 다시 붙이기
		String originalFileName=file.getOriginalFilename();
		
		// 파일 이름이 이름.확장자 일떄 .분할하고 확장자 획득(.이 확장자가 아닌 파일명에도 들어갔을때 구분 불가)
		//String extension=file.getOriginalFilename().split("[.]")[1]; // 확장자
		
		// 문자열로된 파일 이름을 뒷부분부터 '.'을 검색해서 잘라내서 확장자만 획득(.이 확장자가 아닌 파일명에도 들어갔을때 구분을 위해)
		String extension = originalFileName.substring(originalFileName.lastIndexOf(".")); //파일 확장자
		System.out.println("확장자(.확장자): "+extension);
		
		String savedFileName=UUID.randomUUID()+extension; // 저장될 파일명(랜덤)
		System.out.println("savedFileName: : "+savedFileName);
		
		String uri = "/summernote/images/";
		ClassPathResource cpr=new ClassPathResource("static"+uri); // static/summernote/images/
		
		File location=cpr.getFile(); // 이미지가 업로드되는 위치
		
		file.transferTo(new File(location, savedFileName)); // 파일을 업로드
		
		//map
		HashMap<String, String> result=new HashMap<>();
		result.put("url", uri+savedFileName);
		result.put("responseCode", "success");
		
		
		return result; // /summernote/images/저장될 파일명
	}
}
