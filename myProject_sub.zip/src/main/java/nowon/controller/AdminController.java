package nowon.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminController {

	// 관리자페이지 이동
	@GetMapping("/admin")
	public String adminpage() {
		return "admin/default";
	}
	
	// 상품 페이지 이동
	@GetMapping("/admin/goods-page")
	public String goodsPage() {
		return "/admin/goods/write";
	}
}
