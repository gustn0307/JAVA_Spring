package nowon.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import nowon.domain.dto.member.MemberSaveDto;
import nowon.service.MemberService;
import nowon.service.impl.MemberServicdImpl;

@Controller
public class LogController {

	@Autowired
	MemberService service;
	
	// 인증이 필요할떄 호출이 되고 로그인페이지로 이동
	@GetMapping("/login")
	public String login() {
		return "log/signin";
	}
	
	 
	@GetMapping("/log/signin")
	public String signin() {
		return "redirect:/"; // 인덱스 페이지로 이동
	}
	
	// 회원가입 페이지 이동
	@GetMapping("/log/signup")
	public String signup() {
		return "log/signup";
	}
	
	// 회원가입 처리
	@PostMapping("/log/signup")
	public String signup(MemberSaveDto dto, Model Model) {
		service.save(dto, Model);
		return "log/signin";
	}
	
	@ResponseBody
	@PostMapping("/log/email")
	public boolean exitsEmail(String email) {
		System.out.println("email: "+email);
		return service.isExistsEmail(email);
	}
	
	
}
