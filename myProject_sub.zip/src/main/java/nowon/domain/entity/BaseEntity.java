package nowon.domain.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Getter;

@Getter
@EntityListeners(AuditingEntityListener.class)
@MappedSuperclass // 별도로 엔티티 만들어지지 않고 테이블안에 추가됨
public class BaseEntity {
	
	@CreatedDate
	@Column(columnDefinition="TIMESTAMP", updatable=false)
	LocalDateTime createdDate;
	
	@LastModifiedDate
	@Column(columnDefinition="TIMESTAMP")
	LocalDateTime updatedDate;
	
}
