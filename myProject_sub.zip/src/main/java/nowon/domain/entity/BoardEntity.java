package nowon.domain.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import nowon.domain.dto.board.BoardUpdateDto;
import nowon.security.MemberEntity;

@DynamicUpdate // 원본과 비교하여 수정된 데이터만 update
@Builder
@Getter
@RequiredArgsConstructor
@AllArgsConstructor
@Table(name="board")
@Entity
public class BoardEntity extends BaseEntity{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long bno;
	
	@Column(nullable=false)
	private String subject;
	
	@Column(columnDefinition = "text not null")
	private String content;
	
	private int readCount;
	
	// N:1 FK의 관계로 연결된 엔티티에서 설정
	// JPA에서 관계를 고민할 떄는 FK쪽을 먼저 해석해보면 편리
	// MemberEntity에서 OneToMany로 접근해도 가능하긴 함
	@ManyToOne(fetch = FetchType.LAZY) // getMember() 실행 시 읽어온다, member 하나로 MemberEntity의 여러 정보들에 접근하므로 ManyToOne, 
	@JoinColumn(name="writer") // 설정 안해주면 member_email로 생성됨
	private MemberEntity member; // MemberEntity의 정보들을 접근 가능
	
	// 제목과 내용 수정하는 메소드
	public BoardEntity update(BoardUpdateDto dto) {
		subject=dto.getSubject();
		content=dto.getContent();
		return this;
	}
}
