package nowon.domain.entity;

import java.util.List;
import java.util.Vector;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString(exclude = "files")
@DynamicUpdate
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Table(name="goods")
@Entity
public class GoodsEntity extends BaseEntity{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long gno;
	
	@Column(nullable=false)
	private String subject; 
	
	@Column(columnDefinition="text not null")
	private String content;
	
	
	@Builder.Default
	@OneToMany(fetch=FetchType.LAZY,
				mappedBy="goods",
				cascade=CascadeType.ALL)
	List<FileEntity> files=new Vector<FileEntity>();
	public void addFile(FileEntity file) {
		files.add(file);
	}
	
	
}
