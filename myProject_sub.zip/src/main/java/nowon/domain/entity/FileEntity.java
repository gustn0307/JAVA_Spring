package nowon.domain.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Table(name="file")
@Entity
public class FileEntity extends BaseEntity{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long fno;
	
	private String orgName;
	private String newName;
	private String location; // 업로드 위치
	private long size; // 파일 크기
	
	@JoinColumn(name="gno") // 양방향에서 owner역할을 하고 many쪽(file)에 인자로 준 컬럼 생성
	@ManyToOne(fetch=FetchType.LAZY)
	GoodsEntity goods;
}
