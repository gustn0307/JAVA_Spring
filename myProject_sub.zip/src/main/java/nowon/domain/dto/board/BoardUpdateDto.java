package nowon.domain.dto.board;

import lombok.Data;

@Data
public class BoardUpdateDto {
	private String subject;
	private String content;
}
