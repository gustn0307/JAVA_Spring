package nowon.domain.dto.board;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.EqualsAndHashCode;
import nowon.domain.dto.member.MemberListDto;
import nowon.domain.entity.BoardEntity;

@Data
public class BoardDetailDto{

	private long bno;
	private String subject;
	private String content;
	
	private int readCount;
	private MemberListDto member;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	public BoardDetailDto(BoardEntity entity) {
		
		this.bno = entity.getBno();
		this.subject = entity.getSubject();
		this.content=entity.getContent(); // 내용 포함
		this.readCount = entity.getReadCount();
		this.member = new MemberListDto(entity.getMember());
		this.createdDate=entity.getCreatedDate();
		this.updatedDate=entity.getUpdatedDate();
	} 
	
	
	
	
}
