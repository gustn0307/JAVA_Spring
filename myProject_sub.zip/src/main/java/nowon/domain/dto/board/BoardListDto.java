package nowon.domain.dto.board;


import java.time.LocalDateTime;

import lombok.Data;
import lombok.EqualsAndHashCode;
import nowon.domain.dto.member.MemberListDto;
import nowon.domain.entity.BoardEntity;


@EqualsAndHashCode(callSuper=false)
@Data
public class BoardListDto{

	private long bno;
	private String subject;
	private String content;
	
	private int readCount;
	private MemberListDto member;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	public BoardListDto(BoardEntity entity) {
		
		this.bno = entity.getBno();
		this.subject = entity.getSubject();
		this.readCount = entity.getReadCount();
		this.member = new MemberListDto(entity.getMember());
		this.createdDate=entity.getCreatedDate();
		this.updatedDate=entity.getUpdatedDate();
	} 
	
	
	
	
}
