package nowon.domain.dto.board;

import lombok.Data;
import nowon.domain.entity.BoardEntity;
import nowon.security.MemberEntity;

@Data
public class BoardSaveDto {
	private String subject;
	private String content;
	private String email; // MemberEntity의 pk에 적용할 data
	
	public BoardEntity toEntity() {
		
		return BoardEntity.builder()
				.subject(subject).content(content)
				.member(MemberEntity.builder().email(email).build())
				.build();
	}
	
}
