package nowon.domain.dto.member;

import lombok.Data;
import nowon.security.MemberEntity;

@Data
public class MemberListDto {
	
	private String email; 
	private String name; 
	private boolean isSocial;
	
	public MemberListDto(MemberEntity entity) {
		this.email = entity.getEmail();
		this.name = entity.getName();
		this.isSocial = entity.isSocial();
	}

	
}
