package nowon.domain.dto.member;

import lombok.Data;
import nowon.security.MemberEntity;
import nowon.security.MemberRole;

@Data
public class MemberSaveDto { // DTO(Data Transfer Object): 계층 간 데이터 교환 역할
	private String email;
	private String pass;
	private String name;
	private String userIp;
	
	public MemberEntity toEntity() {
		MemberEntity entity=MemberEntity.builder()
										.email(email)
										.pass(pass)
										.name(name)
										.userIp(userIp)
										.build();
		
		entity.addRole(MemberRole.USER);
		
		return entity;
	}
}
