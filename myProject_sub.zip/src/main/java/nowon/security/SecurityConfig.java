package nowon.security;

import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;


@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder(16); // 강도 default는 10, 4~31까지 적용 가능
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		//super.configure(http); // 모든 URI에 대해 인증(authentication) 필요
		//security 구조 : https://docs.spring.io/spring-security/reference/servlet/architecture.html
		http.authorizeHttpRequests() // 인증이 필요한 자원들을 설정
			.antMatchers("/","/login","/log/signup","/log/email").permitAll() // 설정된 주소 "/"(루트)페이지에 대한 모든 사용자 허용
			.antMatchers(HttpMethod.GET, "/boards/**").permitAll()
			.antMatchers("/admin/**").hasRole("ADMIN") 			
			.anyRequest().authenticated() // 설정된 주소 "/"(루트)페이지 나머지 주소는 인증이 필요(로그인 페이지로 넘어감)-->/login 호출
			;
		
		// 인가(authorization)에 문제 발생시 로그인 화면
		http.formLogin() // formLogin은 security에서 default로 제공하는 로그인 페이지
			.loginPage("/login") // user가 설정한 로그인 페이지로 설정(커스터마이징)
			.loginProcessingUrl("/log/login") // form 태그의 action-->UserDetailsService
			.usernameParameter("email") // username -> email
			.passwordParameter("pass") // password -> pass
			;  
		
		http.csrf().disable();
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring()
			.antMatchers("/summernote/**") // summernote 파일들에 대한 접근 허용
			.antMatchers("/css/**","/file/**","/images/**","/js/**"); // css파일들에 대한 접근 허용
	} 
	
}
