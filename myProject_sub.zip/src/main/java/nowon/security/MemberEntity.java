package nowon.security;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import nowon.domain.entity.BaseEntity;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Table(name="member")
@Entity
public class MemberEntity extends BaseEntity{ // 테이블 만들기
	
	@Id
	private String email; // 대소문자를 구분하기 위해 db에서 조합을 utf8mb4_bin으로 설정
	
	@Column(nullable=false)
	private String pass;
	
	@Column(nullable=false)
	private String name; // utf8mb4_ci는 대소문자를 구분하지 않을 때 사용
	
	private String userIp;
	
	private boolean isSocial;
	
	@ElementCollection(fetch=FetchType.EAGER)
	@Enumerated(EnumType.STRING) // db에 저장될 떄 타입을 string으로 저장
	@Builder.Default
	private Set<MemberRole> roles=new HashSet<MemberRole>();
	
	// roles를 세팅을 편하게 하기위한 메소드 
	public void addRole(MemberRole role) {
		roles.add(role);
		
	}
}
