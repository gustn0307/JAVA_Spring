package nowon.security;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class MyUserDetailService implements UserDetailsService {

	// email과 pass 정보를
	// AuthenticationManager-AuthenticationProvider-DaoAuthenticationProvider를 거쳐서
	// UserDetailsService로 도착해 DB의 아이디와 비밀번호가 일치하는지 확인
	@Autowired
	private MemberEntityRepository repository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		System.out.println("email: " + username);
		// 1. db에 email이 존재하는지 확인(repository를 통해)
		// repository.findById(username);
		
		// email을 조건으로 조회하는 쿼리 메소드
		Optional<MemberEntity> result=repository.findByEmail(username);
		
		if(result.isEmpty()) {
			// 존재하지 않으면 UsernameNotFoundException 에러 발생
			throw new UsernameNotFoundException("유저가 존재하지 않습니다.");
		}
		
		// username(email 정보)가 존재하면 MyUserDetails 타입으로 리턴
		
		// email, pass, 권한들을 넘겨주어야 함
		return new MyUserDetails(result.get()); // User : 유저 정보를 저장하고 있는 객체
	}

}
