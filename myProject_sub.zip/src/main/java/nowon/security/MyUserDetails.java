package nowon.security;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import java.util.stream.Collectors;
import lombok.Getter;

@Getter
public class MyUserDetails extends User{

	private String name;

	public MyUserDetails(MemberEntity memberEntity) {
		super(
				memberEntity.getEmail(), // id
				memberEntity.getPass(),  // pass
				memberEntity.getRoles() // roles
							.stream()
							.map(role->new SimpleGrantedAuthority(role.getRole())) // "ROLE_"
								.collect(Collectors.toSet()	)
			);
		name=memberEntity.getName();
	}

}
