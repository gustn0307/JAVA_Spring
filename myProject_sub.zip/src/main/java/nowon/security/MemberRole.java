package nowon.security;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum MemberRole {
	// 상수를 가독성을 위해 문자로 표현
	USER("회원", "ROLE_USER"),
	ADMIN("관리자","ROLE_ADMIN");

	final String title;
	final String role;
	
}
