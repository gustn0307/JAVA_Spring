package nowon.service;

import org.springframework.ui.Model;

import nowon.domain.dto.board.BoardSaveDto;
import nowon.domain.dto.board.BoardUpdateDto;

public interface BoardService {

	void list(Model model); // 게시글 목록 확인

	void save(BoardSaveDto dto); // 게시글 저장

	void detail(long bno, Model model); //게시글 내용 확인

	void update(long bno, BoardUpdateDto dto); // 게시글 수정
 
	void delete(long bno); // 게시글 삭제

}
