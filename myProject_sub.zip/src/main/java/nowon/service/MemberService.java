package nowon.service;

import org.springframework.ui.Model;

import nowon.domain.dto.member.MemberSaveDto;

public interface MemberService {

	void save(MemberSaveDto dto, Model model);

	boolean isExistsEmail(String email);



}
