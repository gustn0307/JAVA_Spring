package nowon.service.impl;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import nowon.domain.dto.member.MemberSaveDto;
import nowon.security.MemberEntity;
import nowon.security.MemberEntityRepository;
import nowon.service.MemberService;
import nowon.utils.ClientIP;

@Service
public class MemberServicdImpl implements MemberService {

	@Autowired
	HttpServletRequest request;
	
	@Autowired
	private PasswordEncoder PasswordEncoder;
	
	@Autowired
	MemberEntityRepository repository;
	
	//회원가입 처리
	@Override
	public void save(MemberSaveDto dto, Model model) {
		dto.setUserIp(ClientIP.getClientIP(request));
		dto.setPass(PasswordEncoder.encode(dto.getPass()));
		repository.save(dto.toEntity());
		
		model.addAttribute("msg",dto.getName()+"님! 회원가입이 완료되었습니다.");
	}

	@Override
	public boolean isExistsEmail(String email) {
		
		Optional<MemberEntity> result=repository.findByEmail(email);
		if(result.isEmpty()) { // isPresent(): 이미 해당 이메일을 사용하는 회원이 있음(사용불가)
			return true; // isEmpty() : 해당 이메일을 사용하는 회원이 있음(사용가능)
		}
		return false; // 
	}


}
