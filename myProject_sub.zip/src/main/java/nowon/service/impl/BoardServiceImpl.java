package nowon.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.ui.Model;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import nowon.domain.entity.BoardEntity;
import nowon.domain.entity.BoardEntityRepository;
import nowon.service.BoardService;
import nowon.domain.dto.board.BoardDetailDto;
import nowon.domain.dto.board.BoardListDto;
import nowon.domain.dto.board.BoardSaveDto;
import nowon.domain.dto.board.BoardUpdateDto;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	BoardEntityRepository repository;
	
	@Transactional // 영속석 LAZY 적용시 반영해주어야 함
	@Override
	public void list(Model model) { // DB에서 list를 읽어와 페이지에 보내줌
		List<BoardListDto> result=repository.findAll().stream()
										.map(BoardListDto::new)
										.collect(Collectors.toList());
		
		model.addAttribute("list",result); // 페이지에서 list 이름으로 데이터를 읽어들일 수 있음
		
	}

	@Override
	public void save(BoardSaveDto dto) {
		repository.save(dto.toEntity());
	}

	@Transactional
	@Override
	public void detail(long bno, Model model) {
		// BoardEntity --> BoardDetailDto
		BoardDetailDto result = repository.findById(bno)
											.map(BoardDetailDto::new)
											// map()의 다른 표현식들
//											.map(new Function<BoardEntity, BoardDetailDto>(){
//
//												@Override
//												public BoardDetailDto apply(BoardEntity t) {
//													// TODO Auto-generated method stub
//													return new BoardDetailDto(t);
//												}
//											});
											//.map(entity-> new BoardDetailDto(entity));
											//.map(entity->{return new BoardDetailDto(entity);});
											.orElseThrow();
											
		model.addAttribute("detail", result);			
	}

	@Transactional
	@Override
	public void update(long bno, BoardUpdateDto dto) {
		repository.findById(bno)
					.map(entity->entity.update(dto));
					//.map(entity->{return entity.update(dto);});
		
	}

	@Override
	public void delete(long bno) {
		repository.deleteById(bno);
	}

}
