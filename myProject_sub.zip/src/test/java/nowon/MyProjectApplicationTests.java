package nowon;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import nowon.domain.entity.BoardEntity;
import nowon.domain.entity.BoardEntityRepository;
import nowon.security.MemberEntity;
import nowon.security.MemberEntityRepository;
import nowon.security.MemberRole;

@SpringBootTest
class MyProjectApplicationTests {

	@Autowired
	BoardEntityRepository repo;
	
	@Autowired
	MemberEntityRepository memberEntityRepository;
	
	//@Test
	void 게시글저장() {
		MemberEntity member=memberEntityRepository.findById("test1@test.com").get();
		
		BoardEntity board= BoardEntity.builder()
				.subject("테스트").content("내용테스트")
				.member(member)
				.build();
		
		repo.save(board);
		
	}	
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	//@Test
	void 관리자생성() {
		
		MemberEntity member=MemberEntity.builder()
							.email("admin@test.com")
							.pass(passwordEncoder.encode("1234"))
							.name("관리자")
							.build();
		
		member.addRole(MemberRole.USER);
		member.addRole(MemberRole.ADMIN);
		
		memberEntityRepository.save(member);		
	}
}
