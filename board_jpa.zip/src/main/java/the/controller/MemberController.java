package the.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import lombok.RequiredArgsConstructor;
import the.domain.dto.member.MemberLoginDto;
import the.domain.dto.member.MemberSaveDto;
import the.service.MemberService;
import the.service.impl.MemberServiceImpl;

@RequiredArgsConstructor
@Controller
public class MemberController {
	
	//@Autowired //:멤버필드 인젝션방법
	final MemberService service;
	// 생성자 인젝션방법 : final 필드 + @RequiredArgsConstructor
	
	@GetMapping("/mem/reg")
	public String regPage() {
		return "member/registration";
	}
	
	@PostMapping("/mem/reg")
	public String memberReg(MemberSaveDto saveDto, Model model) {
		return service.save(saveDto , model);
	}
	
	//로그인페이지 이동
	@GetMapping("/mem/login")
	public String loginPage() {
		return "member/login";
	}
	
	//로그인 기능 처리
	@PostMapping("/mem/login")
	public String login(MemberLoginDto loginDto, Model model) {
		return service.login(loginDto, model);
	}
	
	@GetMapping("/mem/logout")
	public String logout() {
		return service.logout();
	}
	
}
