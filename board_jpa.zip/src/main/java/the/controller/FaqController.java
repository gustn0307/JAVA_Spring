package the.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.RequiredArgsConstructor;
import the.domain.entity.Division;
import the.service.FaqService;
import the.service.impl.FaqServiceImpl;

@RequiredArgsConstructor
@Controller
public class FaqController {

	private final FaqService service;
	
	@GetMapping("/faq/{division}")
	public String list(Model model,@RequestParam(defaultValue = "1")int page,
					@PathVariable int division) {
		//System.out.println(division);
		return service.pagedList(division, page, model);
	}
}