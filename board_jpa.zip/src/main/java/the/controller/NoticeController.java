package the.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.RequiredArgsConstructor;
import the.domain.dto.notice.NoticeUpdateDto;
import the.service.NoticeService;
import the.service.impl.NoticeServiceImpl;

@RequiredArgsConstructor
@Controller
public class NoticeController {
	
	final NoticeService service;
	
	@GetMapping("/notices") // ?page=1  Query String Patameter
	public String list(Model model, @RequestParam(defaultValue = "1")int page) {
		//return service.getList(model); //모든 list 갖고오는경우
		return service.getPageList(model, page);
		//return service.getJpqlLIst(model, page);
	}
	
	@GetMapping("/notices/{no}")
	public String detail(@PathVariable long no,Model model) {
		return service.getDetail(no, model);
	}
	
	@DeleteMapping("/notices/{no}")
	public String delete(@PathVariable long no) {
		return service.delete(no);
	}
	
	@PutMapping("/notices/{no}")               //제목,내용 파라미터 매핑
	public String update(@PathVariable long no, NoticeUpdateDto dto) {
		return service.updateSubjectAndContent(no, dto);
	}
	
	
}
//                   url              메서드   template 
//공지사항 목록        : /notices          get    notice/list.html
//공지사항 글쓰기페이지  : /notices/write   get    notice/write.html
//공지사항 글쓰기 처리  : /notices         post    redirect:/notices
//공지사항 상세페이지   : /notices/{글번호}   get    notice/detail.html
//공지사항 수정페이지   : /notices/{글번호}   Put    redirect:/notices/{글번호}
//공지사항 삭제페이지   : /notices/{글번호}   delete redirect:/notices