package the.service.impl;

import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import lombok.RequiredArgsConstructor;
import the.domain.dto.notice.NoticeListDto;
import the.domain.dto.notice.NoticeUpdateDto;
import the.domain.dto.util.PageDto;
import the.domain.entity.Notice;
import the.domain.entity.NoticeRepository;
import the.service.NoticeService;

@RequiredArgsConstructor
@Service
public class NoticeServiceImpl implements NoticeService {
	
	final NoticeRepository repository;
	
	
	@Override
	public String getJpqlLIst(Model model, int page) {
		List<NoticeListDto> result=repository.getListAsOracle()
											.stream().map(NoticeListDto::new)
											.collect(Collectors.toList());
		model.addAttribute("list", result);
		//EntityManager em;
		//TypedQuery<Notice> query;
		
		return "notice/list";
	}

	//page 처리해서 list 읽어오기
	@Override
	public String getPageList(Model model, int page) {
		long startTime=System.nanoTime();
		//int page=1;//첫페이지 가 0부터세팅
		if(page<1)page=1;
		int size=5;//읽어올 레코드(공지사항) 개수 
		Pageable pageable=PageRequest.of(page-1, size, Direction.DESC, "no");
		
		//List<NoticeListDto> result=repository.findAll(pageable).map(NoticeListDto::new).getContent();
		Page<Notice> result=repository.findAll(pageable);
		List<NoticeListDto> list=result.map(NoticeListDto::new).getContent();
		
		System.out.println("총페이지수 : " + result.getTotalPages() );
		
		
		int pageGroup=5; //한페이지에 표현할 페이지 개수  {1,2,3,4,5},{6,7,8,9,10}
									//pageGroupNo      1           2      
		
		model.addAttribute("pd", new PageDto(pageGroup, page , result.getTotalPages()));
		model.addAttribute("list", list);
		
		System.out.println("소요시간 : "+((System.nanoTime()-startTime) / Math.pow(10,9)));
		return "notice/list";
	}
	
	@Override
	public String getList(Model model) {
		List<NoticeListDto> list=repository.findAll().stream()
											.map(NoticeListDto::new)
											.collect(Collectors.toList());
		/*
		List<NoticeListDto> result=new Vector<>();
		for(Notice entity : repository.findAll()) {
			NoticeListDto dto=new NoticeListDto(entity);
			result.add(dto);
		}
		*/
		model.addAttribute("list", list);
		
		return "notice/list";
	}

	@Override
	public String getDetail(long no, Model model) {
		model.addAttribute("detail", repository.findById(no).map(NoticeListDto::new).orElseThrow() );
		return "notice/detail";
	}

	@Override
	public String delete(long no) {
		repository.deleteById(no);
		return "redirect:/notices"; //삭제후 리스트 페이지 
	}

	@Transactional
	@Override
	public String updateSubjectAndContent(long no, NoticeUpdateDto dto) {
		//1.트랜잭션 적용할지 말지..
		//1.1트랜잭션 미적용... save()
		//1.1.1문제가발생하는경우 : update대상만 entity객체에 셋팅해서 저장하면 나머지는 null or 0 등으로 같이수정된다.
		//Notice entity=Notice.builder().no(no).subject(dto.getSubject()).content(dto.getContent()).build();
		//Notice entity=dto.toEntity();
		//repository.save(entity); //no(PK) 가 DB에 존재하면 update  
		//1.1.2수정할 데이터만 정상수정 할려면..
		//정상적으로 처리하기위해 먼저 ID(PK)를 이용해서 먼저 수정할 원본레코드가 읽어오자
		//그리고 수정할 정보만 수정하고 저장
		/*
		Notice entity=repository.findById(no).get();//수정전 원본데이터
		entity.update(dto); //원본 + update처리된 객체
		//repository.save(entity);
		 */
		//1.2트랜잭션 적용
		//repository.findById(no).map(e->{e.update(dto);return null;});
		//repository.findById(no).map(e->{return e.update(dto);});
		repository.findById(no).map(e->e.update(dto));
		
		return "redirect:/notices/"+no; // "redirect:/notices/1" get매핑이처리 : 상세페이지이동
	}

	


	

}