package the.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Vector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import the.domain.dto.board.BoardDetailDto;
import the.domain.dto.board.BoardListDto;
import the.domain.dto.board.BoardSaveDto;
import the.domain.dto.board.BoardUpdateDto;
import the.domain.dto.util.PageDto;
import the.domain.entity.BoardEntity;
import the.domain.entity.BoardEntityRepository;
import the.service.BoardService;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	private BoardEntityRepository repository;
	
	@Override
	public String listAll(Model model) {
		Sort sort=Sort.by(Direction.DESC, "no");// order by no desc
		List<BoardListDto> list=repository.findAll(sort).stream() //list콜렉션에서 entity객체를 하나씩..
											//.map((e)-> new BoardListDto(e) )
											.map(BoardListDto::new) //entity->BoardListDto로 데이터변경
											.collect(Collectors.toList());// dto를 list로 add
		model.addAttribute("list", list);
		return "board/list"; //board/list.html
	}
	
	//BoardEntity-->BoardListDto 데이터이동시켜서
	@Override
	public String list(Model model) {
		Sort sort=Sort.by(Direction.DESC, "no");// order by no desc
		List<BoardEntity> result=repository.findAll(sort);
		//*		
		List<BoardListDto> list=new Vector<>();
		for(BoardEntity e:result) {
			//BoardListDto dto1=BoardListDto.builder().build();
			//BoardListDto dto2=new BoardListDto();
			//BoardListDto dto3=new BoardListDto(0, null, null, 0, null);
			//content 빼고 세팅
			BoardListDto dto=BoardListDto.builder()
					.no(e.getNo())
					.subject(e.getSubject())
					.writer(e.getWriter())
					.readCount(e.getReadCount())
					.createdDate(e.getCreatedDate())				
					.build();
			list.add(dto);
		}
		//*/
		
		model.addAttribute("list", list);
		
		return "board/list"; //board/list.html
	}

	//디테일 페이지 처리+조회수++
	@Override
	public String detail(long no, Model model) {
		
		//jpa는 update도 save()로 합니다.
		//pk:no 값이 셋팅 no=1 되어있고 DB에 동일레코드가 존재하면 수정처리: 모든컬럼수정
		//1. pk를 이용해서 recode가 존재확인 
		BoardEntity entity=repository.findById(no).get().updateReadCount();
		//2. 수정할 컬럼만 수정
		//entity.updateReadCount();
		System.out.println("readCount chekc : "+entity);
		repository.save(entity);
		
		
		
		BoardDetailDto detailDto=repository.findById(no)
											.map(BoardDetailDto::new)
											.orElseThrow();
		
		
		
		model.addAttribute("detail", detailDto);
		
		/*
		 * Optional<BoardEntity> result=repository.findById(no);
		if(result.isPresent()) {
			BoardDetailDto detailDto=new BoardDetailDto(result.get());
			model.addAttribute("detail", detailDto);
		}
		*/
		//BoardEntity result2=repository.findById(no).orElseThrow();
		
		
		return "board/detail"; //board/detail.html
	}

	//삭제처리
	@Override
	public String delete(long no) {
		repository.deleteById(no);
		System.out.println(no+"번 게시글 삭제완료!");
		return "redirect:/board"; //list.html
	}

	@Transactional
	@Override
	public String detailAndReadCount(long no, Model model) {
		//BoardEntity entity=repository.findById(no).orElseThrow();
		//entity객체정보를 dto객체로 매핑
		//BoardDetailDto dto=new BoardDetailDto(entity);
		
		
		BoardDetailDto dto=repository.findById(no) // DB에 저장된 원본 entity
				//.map(entity->new BoardDetailDto(entity))
				.map(e->e.updateReadCount()) // DB에 저장된 원본에서 readCount++된 entity
				.map(BoardDetailDto::new)// entity 인자로하는 생성자
				.orElseThrow();
		
		model.addAttribute("detail", dto);
		return "board/detail";
	}

	@Transactional
	@Override
	public String update(long no, BoardUpdateDto dto) {
		System.out.println("---update-----");
		repository.findById(no)
					.map(e->e.updateSubjectAndContent(dto));
		System.out.println("제목, 내용 수정처리 됩니다.!");
					
		return "redirect:/board/"+no;
	}

	@Override
	public String listPage(int page,Model model) {
		//int page=1; // 현실의 1페이지
		int size=7;
		
		Sort sort=Sort.by(Direction.DESC, "no");
		Pageable pageable=PageRequest.of(page-1, size, sort);
		//Pageable pageable=PageRequest.of(page, size, Direction.DESC, "no");
	
		Page<BoardEntity> result=repository.findAll(pageable);
		//int pageTot=result.getTotalPages();
		//System.out.println("총페이지수 : " +pageTot );
		
		model.addAttribute("pd", new PageDto(5, page, result.getTotalPages()));
		
		List<BoardListDto> dto=result.getContent().stream()
							.map(BoardListDto::new)
							.collect(Collectors.toList());
		
		model.addAttribute("list", dto);
		return "board/list";
	}

	//글쓰기 기능처리
	@Override
	public String save(BoardSaveDto saveDto) {
		
		repository.save( saveDto.toEntity() ); //entity로만 save
		
		return "redirect:/board";
	}

	

}