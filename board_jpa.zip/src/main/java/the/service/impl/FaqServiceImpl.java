package the.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import lombok.RequiredArgsConstructor;
import the.domain.dto.faq.FaqListDto;
import the.domain.entity.Division;
import the.domain.entity.FaqEntity;
import the.domain.entity.FaqEntityRepository;
import the.service.FaqService;

@RequiredArgsConstructor
@Service
public class FaqServiceImpl implements FaqService {

	private final FaqEntityRepository repository;
	
	@Override
	public String pagedList(int _division,int page,Model model) {
		Division division=Division.MOVIE;
		for(Division div :Division.values()) {
			if(div.ordinal()== (_division-1) ) {
				division=div;
			}
		}
		
		System.out.println("division: "+division);
		//int page=_page;
		
		int size=3;
		Pageable pageable=PageRequest.of(page-1, size, Direction.ASC, "subject");
		
		Page<FaqEntity> result=repository.findByDivision(division, pageable);
		
		List<FaqListDto> list=result.map(FaqListDto::new).getContent();
		/*
		List<FaqListDto> list=result.getContent().stream()
									.map(FaqListDto::new)
									.collect(Collectors.toList());
									*/
		model.addAttribute("div", division.ordinal()+1);
		model.addAttribute("end", result.getTotalPages());
		model.addAttribute("list", list);
		return "faq/list";
	}

}