package the.service;

import org.springframework.ui.Model;

import the.domain.dto.notice.NoticeUpdateDto;

public interface NoticeService {

	String getList(Model model);

	String getDetail(long no, Model model);

	String delete(long no);

	String updateSubjectAndContent(long no, NoticeUpdateDto dto);

	String getPageList(Model model, int page);

	String getJpqlLIst(Model model, int page);

}