package the.domain.dto.board;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import the.domain.entity.BoardEntity;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
public class BoardDetailDto {
	private long no;
	private String subject;
	private String content;
	private String writer;
	private int readCount;
	private LocalDateTime createdDate;
	
	//BoardEntity 객체의 필드값을 -> BoardDetailDto 필드로 매핑
	public BoardDetailDto(BoardEntity entity) {
		this.no = entity.getNo();
		this.subject = entity.getSubject();
		this.content=entity.getContent();
		this.writer = entity.getWriter();
		this.readCount = entity.getReadCount();
		this.createdDate = entity.getCreatedDate();
	}
	
	
}
