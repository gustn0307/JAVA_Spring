package the.domain.dto.board;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import the.domain.entity.BoardEntity;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
public class BoardListDto {
	private long no;
	private String subject;
	private String writer;
	private int readCount;
	private LocalDateTime createdDate;
	
	public BoardListDto(BoardEntity entity) {
		this.no = entity.getNo();
		this.subject = entity.getSubject();
		this.writer = entity.getWriter();
		this.readCount = entity.getReadCount();
		System.out.println("---------------------");
		System.out.println(entity);
		this.createdDate = entity.getCreatedDate();
	}
	
	
}
