package the.domain.dto.notice;

import lombok.Getter;
import lombok.Setter;
import the.domain.entity.Notice;

@Getter
@Setter // web-> dto 에 매핑하기위해 setter메서드 필요
public class NoticeUpdateDto {
	private String subject;
	private String content;
	
	public Notice toEntity() {
		return Notice.builder().subject(subject).content(content).build();
	}
}