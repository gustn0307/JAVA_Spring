package the.domain.dto.member;

import lombok.Data;

@Data
public class MemberLoginDto {
	
	private String email;
	private String password;

}
