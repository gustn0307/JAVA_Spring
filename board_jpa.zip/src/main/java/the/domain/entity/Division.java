package the.domain.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;



@RequiredArgsConstructor
@Getter
public enum Division {
	MOVIE("영화관 이용"), //0
	LPOINT("L.POINT"), //1
	MEMBER("회원"),     //2 
	MEMBER_SHIP("멤버십"),
	ONLINE("온라인"),
	BENEFIT("할인혜택"),
	TICKET("관람권"),
	STORE("스토어"),
	SPECAIL("스페셜관");
	
	private final String value;
	
}