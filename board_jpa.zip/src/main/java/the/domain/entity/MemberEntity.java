package the.domain.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@NoArgsConstructor
@Builder
@AllArgsConstructor
@Getter
@SequenceGenerator(
		name = "gen_seq_me",
		sequenceName = "seq_me",
		initialValue = 1,
		allocationSize = 1		
		)
@EntityListeners(AuditingEntityListener.class) //Auditing 기능 : main class에서 활성화시켜주세요
@Entity
public class MemberEntity {
	
	@Id //pk
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "gen_seq_me")
	private long no;
	
	@Column(nullable = false, unique = true) //not null
	private String email;
	
	@Column(nullable = false) //not null
	private String password;
	
	@Column(columnDefinition = "varchar2(255 char) not null") //not null
	private String name;
	
	@Column(nullable = true) //not null
	@CreatedDate //Entity가 생성될때 자동저장
	private LocalDateTime createdDate; //cerated_date
	
	@Column(nullable = true) //not null
	@LastModifiedDate //Entity가 최초생성시 또는 수정될때마다 자동저장
	private LocalDateTime updatedDate; //updated_date
	
	//비밀번호 수정하는 메서드
	public MemberEntity updatePassword(String password) {
		this.password=password;
		return this;
	}
}
