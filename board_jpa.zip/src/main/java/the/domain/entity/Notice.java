package the.domain.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import the.domain.dto.notice.NoticeUpdateDto;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@EntityListeners(AuditingEntityListener.class)
@SequenceGenerator(name = "gen_seq_notice",
		sequenceName = "seq_notice", initialValue = 1, allocationSize = 1)
@Entity
public class Notice {
	
	@Id
	@GeneratedValue(generator = "gen_seq_notice", strategy = GenerationType.SEQUENCE)
	long no;
	@Column(nullable = false)
	String subject;
	@Column(nullable = false)
	String content;
	@Column
	int readCount;
	@CreatedDate
	LocalDateTime createdDate;
	@LastModifiedDate
	LocalDateTime updatedDate;
	
	//단순수정
	public Notice update(NoticeUpdateDto dto) {
		subject=dto.getSubject();
		content=dto.getContent();
		return this;
	}

}