package the.domain.entity;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FaqEntityRepository extends JpaRepository<FaqEntity, Long>{
	//division 컬럼을 where 절의 조건 컬럼으로 적용
	//OrderBy 정렬 연산자 No : no컬럼을 정렬컬럼으로...
	
	//List<FaqEntity> findByDivisionOrderByNoDesc(Division divsion);
	
	Page<FaqEntity> findByDivision(Division divsion, Pageable pageable);
	
}
