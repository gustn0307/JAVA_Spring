package the.domain.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import the.domain.dto.board.BoardUpdateDto;

@EntityListeners(AuditingEntityListener.class)
@SequenceGenerator(
		name = "gen_bo_seq",
		sequenceName = "seq_entity",
		initialValue = 1,
		allocationSize = 1)
@Entity
@ToString
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BoardEntity {//entity : DB테이블과 매핑하는 클래스 - repositoty
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "gen_bo_seq")
	private long no;
	
	@Column(nullable = false)//not null
	private String subject;
	@Column(nullable = false)//not null
	private String content;
	@Column(nullable = false)//not null
	private String writer;
	
	private int readCount;
	
	@CreatedDate
	private LocalDateTime createdDate;
	
	//조회수 update
	public BoardEntity updateReadCount() {
		readCount++;
		return this;
	}
	//제목 내용 update
	public BoardEntity updateSubjectAndContent(BoardUpdateDto dto) {
		subject=dto.getSubject();
		content=dto.getContent();
		return this;
	}
	
}
