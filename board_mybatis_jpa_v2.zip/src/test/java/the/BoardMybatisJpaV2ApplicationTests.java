package the;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import the.domain.dto.myBoard.MyBoardDto;
import the.domain.entity.Board;
import the.domain.entity.BoardRepository;
import the.mapper.MyBoardMapper;

@SpringBootTest
class BoardMybatisJpaV2ApplicationTests {

	@Autowired
	MyBoardMapper boardMapper;
	
	@Autowired
	BoardRepository reopsitory;
	
	//@Test
	void jpa게시판데이터삽입() {
		IntStream.rangeClosed(1, 100000).forEach(i->{
			Board entity=Board.builder()
					.subject("제목테스트 "+i).content("내용테스트 "+i).writer("작성자"+(i%10+1))
					.build();
			reopsitory.save(entity);
		});
		
	}
	
	//@Test
	void 데이터읽어오기() {
		MyBoardDto myBoardDto=boardMapper.find(1L);
		System.out.println(myBoardDto);
	}
	
	//@Test
	void 더미데이터입력() {
		IntStream.rangeClosed(21, 100000).forEach(i->{
			MyBoardDto myBoardDto=MyBoardDto.builder()
					.subject("제목테스트 "+i).content("내용테스트 "+i).writer("노원그린")
					.build();
			boardMapper.save(myBoardDto);
		});
		
	}

}
