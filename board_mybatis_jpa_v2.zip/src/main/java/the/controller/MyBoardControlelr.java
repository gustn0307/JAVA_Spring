package the.controller;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import the.domain.dto.myBoard.MyBoardDto;
import the.service.MyBoardService;
import the.service.impl.MyBoardServiceImpl;

@Controller
public class MyBoardControlelr {
	
	@Autowired
	private MyBoardService service;
	
	//?page=1 query string parameter가 없을때 int page 매핑에 null->int parse오류발생
	//defaule value 설정하면 된다.
	@GetMapping("/myboards")
	public String list(Model model,@RequestParam(defaultValue = "1") int page) {
		return service.getList(model, page); /* myboard/list.html */
	}
	
	@GetMapping("/myboards/write")
	public String write() {
		return "myboard/write";
	}
	
	@PostMapping("/myboards/write")
	public String write(MyBoardDto dto, MultipartFile file)  throws Exception, Throwable {
		return service.saveAndFileUpload(dto, file);
	}
	
}
