package the.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import the.domain.dto.visual.VisualSaveDto;
import the.service.VisualService;
import the.service.impl.VisualServiceImpl;

@RequiredArgsConstructor
@Controller
public class VisualController {
	
	private final VisualService service;
	
	@GetMapping("/visuals/write")
	public String writePage() {
		return "visual/write";
	}
	
	@ResponseBody
	@PostMapping("/visuals/temp")
	public String temp(MultipartFile file) {
		return service.tempFileUpload(file);
	}
	
	@PostMapping("/visuals/write")
	public String write(MultipartFile file, VisualSaveDto dto) {
		//이미 이미지는  temp폴더에 업로든된상황
		return service.moveAndSave(file, dto);
	}
}
