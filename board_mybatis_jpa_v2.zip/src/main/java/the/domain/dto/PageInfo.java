package the.domain.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Getter
public class PageInfo {
	int pageTotal; //페이지 총 개수
	int from;      //페이지 시작번호
	int to;        //페이지 끝 번호 
	int page;      //페이지번호
	int pageGroup; //한 화면표현할 페이지번호 개수
	
	/**
	 * @param rowsTotal : 총게시글수
	 * @param page      : 현실 페이지번호 시작번호 1 ~  
	 * @param pageGroup : 한 화면표현할 페이지번호 개수
	 * @param limit     : 한페이지에 표현할 rows(게시글) 수
	 */
	public PageInfo(int rowsTotal, int page, int pageGroup, int limit) {
		this.page=page;
		this.pageGroup=pageGroup;
		pageTotal=rowsTotal/limit;
		if(rowsTotal % limit > 0)pageTotal++;
		
		int pageGroupNo = page / pageGroup;
		if(page % pageGroup > 0)pageGroupNo++; 
		this.to = pageGroupNo * pageGroup; //마직막번호를 pageGroup 배수만큼 씩 증가
		this.from = to - pageGroup + 1;    //마지막번호에서 pageGroup 개수만큼 빼고+1
		if(to > pageTotal) to = pageTotal;
	}
	
	/**
	 * @param pageTotal : 총 페이지수
	 * @param page      : 현실 페이지번호 시작번호 1 ~  
	 * @param pageGroup : 한 화면표현할 페이지번호 개수
	 */
	public PageInfo(int pageTotal, int page, int pageGroup) {
		this.page=page;
		this.pageGroup=pageGroup;
		this.pageTotal=pageTotal;
		
		//{1,2,3,4, 5} : pageGroupNo=1 
		//{6,7,8,9,10} : pageGroupNo=2
		int pageGroupNo = page / pageGroup;
		// 1/5(0), 2/5(0), 3/5(0), 4/5(0) ,5/5(1) //정수/정수=정수  
		//나머지가 발생하면 +1
		if(page % pageGroup > 0)pageGroupNo++; 
		
		//페이지 마지막번호 계산 : pageGroupNo * pageGroup
		this.to = pageGroupNo * pageGroup; //마직막번호를 pageGroup 배수만큼 씩 증가
		this.from = to - pageGroup + 1;    //마지막번호에서 pageGroup 개수만큼 빼고+1
		//마직막번호 계산시 배수로 증가시켰기때문에 총페이지수보다 커질수 있다
		if(to > pageTotal) to = pageTotal;
	}
}
