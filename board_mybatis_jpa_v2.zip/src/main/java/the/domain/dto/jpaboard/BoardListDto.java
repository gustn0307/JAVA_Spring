package the.domain.dto.jpaboard;

import java.time.LocalDateTime;

import lombok.Getter;
import the.domain.entity.Board;

@Getter
public class BoardListDto {//entity->dto

	private long no;
	private String subject;
	//private String content;
	private String writer;
	private int readCount;
	private LocalDateTime createdDate;
	private LocalDateTime updatedDate;
	
	public BoardListDto(Board entity) {
		this.no = entity.getNo();
		this.subject = entity.getSubject();
		this.writer = entity.getWriter();
		this.readCount = entity.getReadCount();
		this.createdDate = entity.getCreatedDate();
		this.updatedDate = entity.getUpdatedDate();
	}
	
	
	
}
