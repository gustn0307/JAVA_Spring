package the.mapper;

import org.apache.ibatis.annotations.Mapper;

import the.domain.dto.file.GoodsFileDto;

@Mapper
public interface GoodsFileMapper {

	void save(GoodsFileDto goodsFileDto);

	GoodsFileDto getImgInfo(long gno);

}
