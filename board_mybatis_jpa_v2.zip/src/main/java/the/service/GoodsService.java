package the.service;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import the.domain.dto.goods.Goods;

public interface GoodsService {

	String saveAndImgUpload(Goods dto, MultipartFile file);

	String getList(Model model);

	String tempImgUpload(MultipartFile fileImg);

	String saveAndImgTempToLoc(Goods dto, MultipartFile file);

}
