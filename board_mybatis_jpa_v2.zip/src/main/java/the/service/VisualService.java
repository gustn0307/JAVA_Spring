package the.service;

import org.springframework.web.multipart.MultipartFile;

import the.domain.dto.visual.VisualSaveDto;

public interface VisualService {

	String tempFileUpload(MultipartFile file);

	String moveAndSave(MultipartFile file, VisualSaveDto dto);


}
