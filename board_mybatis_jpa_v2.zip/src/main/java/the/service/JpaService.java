package the.service;

import org.springframework.ui.Model;

public interface JpaService {


	String getList(Model model, int page);

}
