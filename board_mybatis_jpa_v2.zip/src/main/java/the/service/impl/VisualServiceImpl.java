package the.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import the.domain.dto.visual.VisualSaveDto;
import the.domain.entity.VisualFile;
import the.domain.entity.VisualFileRepository;
import the.service.VisualService;
import the.util.FileUtils;

@RequiredArgsConstructor
@Service
public class VisualServiceImpl implements VisualService {
	
	
	final VisualFileRepository repository;
	
	@Override
	public String tempFileUpload(MultipartFile file) {
		String tempPath="/images/visual/temp/";
		
		FileUtils.tempImgUpload(file, tempPath);
		
		return tempPath+file.getOriginalFilename(); //"/images/visual/temp/"+파일이름
	}

	@Override
	public String moveAndSave(MultipartFile file, VisualSaveDto dto) {
		String destPath="/images/visual/";
		FileUtils.moveTempToDest(destPath);
		
		//DB에저장?????
		VisualFile entity=VisualFile.builder()
				.fileName(file.getOriginalFilename())
				.filePath(destPath)
				.fileSize(file.getSize())
				.visual(dto.toEntity()) //Visual entity객체...
				.build();
		repository.save(entity);
		
		
		return "visual/write";
	}

	

}
