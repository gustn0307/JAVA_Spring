package the.service.impl;

import java.io.File;
import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import lombok.RequiredArgsConstructor;
import the.domain.dto.PageInfo;
import the.domain.dto.file.FileDto;
import the.domain.dto.myBoard.MyBoardDto;
import the.mapper.MyBoardMapper;
import the.mapper.MyFileMapper;
import the.service.MyBoardService;

@RequiredArgsConstructor
@Service
public class MyBoardServiceImpl implements MyBoardService {

	private final MyBoardMapper myBoardMapper;
	private final MyFileMapper myFileMapper;
	
	@Override
	public String getList(Model model, int page) {
		if(page <1) page=1; // 1페이지 보다 작게 강제입력될경우 1페이지로 셋팅
		
		int limit=10;
		int offset = (page-1) * limit; // 건너뛰는 개수 
		//page=1, offset=0
		//page=2, offset=5
		
		//전제 페이지 수 : 총게시글수/limit 나머지가 존재하면 1페이지추가
		int rowsTotal=myBoardMapper.getRowsTotal();
		System.out.println("총게시글수 : " + rowsTotal);
		
		//int pageTotal=rowsTotal/limit;
		//if(rowsTotal % limit > 0)pageTotal++;
		//PageInfo pageInfo=new PageInfo(pageTotal, page, 5 );
		PageInfo pageInfo=new PageInfo(rowsTotal, page, 5 , limit);
		model.addAttribute("pd", pageInfo);
		
		//mybatis 에서 페이징처리를 지원해주는 객체 : RowBounds
		RowBounds rowBounds=new RowBounds(offset, limit);
		List<MyBoardDto> result=myBoardMapper.pageList(rowBounds);
		model.addAttribute("list", result);
		
		return "myboard/list";
	}

	@Override
	public String saveAndFileUpload(MyBoardDto dto, MultipartFile file) throws Exception, Throwable {
		System.out.println("save전의 no : "+dto.getNo());
		myBoardMapper.save(dto);
		System.out.println("save이후 no : "+dto.getNo());
		
		/*
		 * ///////파일처리////////////////////////////////////////////////////
		 */		System.out.println("dto :" +dto);
		System.out.println("-----------");
		System.out.println("파일사이즈(long) : "+ file.getSize());
		System.out.println("파일이름 : "+file.getName());
		System.out.println("파일이름Org : "+file.getOriginalFilename());
		System.out.println("파일content Type : "+file.getContentType());
		//file.transferTo(new File("",file.getOriginalFilename()));
		//System.out.println(root.getPath());
		//System.out.println(root.getAbsolutePath());
		//물리적주소: 내장서버에서 접근불가 
		//내부서버주소
		String path="/images/";
		ClassPathResource cpr=new ClassPathResource("static"+path);
		File root=cpr.getFile();
		System.out.println(root.getAbsolutePath());
		//System.out.println(root.get);
		
		String fileName=file.getOriginalFilename();//파일이름
		String fileURI=path;
		long fileSize=file.getSize();
		
		FileDto fileDto=FileDto.builder()
				.fileName(fileName).fileURI(fileURI).fileSize(fileSize)
				.bno(dto.getNo())//게시글에 생성된 pk값을 넣어라
				.build();
		myFileMapper.save(fileDto);
		
		file.transferTo(new File(root, fileName));
		//보통파일업로드 처리할때 파일관리를 위해 폴더또는 파일이름을 newName처리한다.
		//웹에서 파일확인하기위한 주소 : /images/img_1.png
		//웹에서 확인하기위한 주소 , 저장된 이름, 다운로드하기위한 size정보도 필요합니다.
		
		return "myboard/write";
	}

}
